import {cookie} from './i18n.js?v=11';
export function initTheme(){document.querySelector('#theme-toggle')?.addEventListener('click',()=>{const root=document.documentElement;const dark=root.dataset.theme==='dark'||(root.dataset.theme==='auto'&&matchMedia('(prefers-color-scheme:dark)').matches);root.dataset.theme=dark?'light':'dark';cookie('theme',root.dataset.theme);});}
