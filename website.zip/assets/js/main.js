import './demo.js';
import {initLanguage} from './i18n.js?v=11';
import {initTheme} from './theme.js?v=11';
import {initNav} from './nav.js?v=11';
import {initConsent,hasConsent} from './cookie-consent.js?v=11';
import {initForms} from './forms.js?v=11';
import {initCalculator} from './calculator.js?v=11';
import {initSlider} from './slider.js?v=11';
import {initAccordions} from './accordion.js?v=11';
import {initMotion} from './motion.js?v=11';
document.documentElement.classList.add('js');
initLanguage();initTheme();initNav();initForms();initCalculator();initSlider();initAccordions();initConsent();
initMotion();
// Optional analytics integration: listen for this event only after installing a reviewed provider.
const conversion=()=>{if(document.body.dataset.page!=='thanks'||!hasConsent('statistics'))return;try{const reference=sessionStorage.getItem('last-submission');if(reference&&!sessionStorage.getItem(`tracked-${reference}`)){document.dispatchEvent(new CustomEvent('consented-conversion',{detail:{type:'enquiry'}}));sessionStorage.setItem(`tracked-${reference}`,'1');}}catch{}};
document.addEventListener('consentchange',conversion);conversion();
