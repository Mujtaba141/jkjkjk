import {data,cookie,readCookie,t} from './i18n.js?v=11';
let consent={statistics:false,marketing:false};
export function hasConsent(category){return consent[category]===true;}
export function initConsent(){
 const banner=document.querySelector('#cookie-banner'), dialog=document.querySelector('#cookie-dialog');
 let saved=null;try{saved=JSON.parse(readCookie('consent')||'null');}catch{}
 if(saved?.version===data.consentVersion&&Date.now()-Date.parse(saved.date)<180*86400000){consent={statistics:saved.statistics===true,marketing:saved.marketing===true};}else if(banner){banner.hidden=false;}
 const apply=()=>{if(!consent.marketing)document.querySelectorAll('#map-container iframe').forEach(frame=>frame.remove());document.dispatchEvent(new CustomEvent('consentchange',{detail:{...consent}}));};
 document.querySelectorAll('[data-cookie-settings]').forEach(button=>button.addEventListener('click',()=>{document.querySelector('#consent-statistics').checked=consent.statistics;document.querySelector('#consent-marketing').checked=consent.marketing;dialog.showModal();}));
 dialog?.querySelector('[data-close]').addEventListener('click',()=>dialog.close());
 document.querySelectorAll('[data-consent]').forEach(button=>button.addEventListener('click',()=>{const choice=button.dataset.consent;consent={statistics:choice==='custom'?document.querySelector('#consent-statistics').checked:choice==='all',marketing:choice==='custom'?document.querySelector('#consent-marketing').checked:choice==='all'};cookie('consent',JSON.stringify({...consent,date:new Date().toISOString(),version:data.consentVersion}),180);banner.hidden=true;dialog.close();apply();}));
 document.querySelector('#load-map')?.addEventListener('click',()=>{if(!hasConsent('marketing')){document.querySelector('[data-cookie-settings]').click();return;}let map;try{map=new URL(data.mapUrl);}catch{return;}if(map.protocol!=='https:'||map.hostname!=='www.google.com'||!map.pathname.startsWith('/maps/embed'))return;const target=document.querySelector('#map-container');if(target.querySelector('iframe'))return;const frame=document.createElement('iframe');frame.src=map.href;frame.title=t('map');frame.loading='lazy';frame.referrerPolicy='no-referrer';target.append(frame);});
 apply();
}
