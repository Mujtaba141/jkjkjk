import {data, t, cookie, readCookie, money} from './i18n.js?v=11';

/* One scheduler owns scroll effects and visible loops. No framework or runtime dependency. */
const root = document.documentElement;
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const fine = matchMedia('(hover: hover) and (pointer: fine)');
const forcedOff = new URLSearchParams(location.search).get('motion') === 'off' || data.motionEnabled === false;
let paused = false; // Animation is enabled by default; OS reduced motion remains respected.
let enabled = false;
let frame = 0;
let lastTime = 0;
let dirty = true;
const visibleLoops = new Set();
const effects = [];
const tweens = new Map();
const clamp = (n, min = 0, max = 1) => Math.max(min, Math.min(max, n));
const ease = n => 1 - (1 - n) ** 3;
const minimal = ['legal'].includes(document.body.dataset.template);

export const motionAllowed = () => enabled && !document.hidden;

function wake() {
    dirty = true;
    if (!frame && !document.hidden) frame = requestAnimationFrame(tick);
}

/** Duration is a fixed millisecond value. Hidden tabs and off-screen elements do no tween work. */
function tween(element, duration, render, finish = () => {}) {
    tweens.get(element)?.finish();
    if (!motionAllowed()) { render(1); finish(); return; }
    tweens.set(element, {duration, elapsed:0, render, finish});
    wake();
}

function tick(time) {
    frame = 0;
    const dt = lastTime ? Math.min(time - lastTime, 50) : 0;
    lastTime = time;
    if (document.hidden) return;
    if (dirty) {
        dirty = false;
        effects.forEach(effect => effect());
        const progress = clamp(scrollY / Math.max(1, document.documentElement.scrollHeight - innerHeight));
        document.querySelector('.back-top circle')?.style.setProperty('stroke-dashoffset', String(1 - progress));
        document.querySelector('.back-top')?.classList.toggle('is-visible', scrollY > 400);
        document.querySelector('[data-side-cta]')?.classList.toggle('is-visible', scrollY > 300);
    }
    if (enabled) {
        visibleLoops.forEach(loop => {
            if (loop.closest('[data-motion="off"]') || loop.matches(':hover, :focus-within')) return;
            loop._motionTime = (loop._motionTime || 0) + dt;
            if (loop.dataset.route === 'loop') drawRoute(loop, (loop._motionTime % 8000) / 8000);
        });
        tweens.forEach((item, element) => {
            const rect = element.getBoundingClientRect();
            if (rect.bottom < 0 || rect.top > innerHeight) { item.render(1); item.finish(); tweens.delete(element); return; }
            item.elapsed += dt;
            const p = clamp(item.elapsed / item.duration);
            item.render(ease(p));
            if (p === 1) { item.finish(); tweens.delete(element); }
        });
    }
    if (enabled && (tweens.size || [...visibleLoops].some(loop => loop.dataset.route === 'loop' && !loop.matches(':hover, :focus-within')))) {
        frame = requestAnimationFrame(tick);
    }
}

function drawRoute(element, progress) {
    const path = element.querySelector('.route-progress');
    const vehicle = element.querySelector('.route-vehicle');
    if (!path || !vehicle) return;
    const length = element._routeLength ??= path.getTotalLength();
    const point = path.getPointAtLength(length * progress);
    const next = path.getPointAtLength(Math.min(length, length * progress + 2));
    const angle = Math.atan2(next.y - point.y, next.x - point.x) * 180 / Math.PI;
    path.style.strokeDashoffset = String(1 - progress);
    vehicle.style.transform = `translate(${point.x}px, ${point.y}px) rotate(${angle}deg)`;
}

function syncPreference() {
    enabled = !forcedOff && !reduced.matches && !paused;
    root.classList.toggle('motion-on', enabled);
    root.classList.toggle('motion-off', !enabled);
    root.classList.toggle('motion-tab-hidden', document.hidden);
    document.querySelectorAll('[data-motion-toggle]').forEach(button => {
        button.textContent = forcedOff || reduced.matches ? t('motion_reduced') : (paused ? t('resume_motion') : t('pause_motion'));
        button.setAttribute('aria-pressed', String(!enabled));
        button.disabled = forcedOff || reduced.matches;
    });
    if (!enabled) {
        tweens.forEach(item => { item.render(1); item.finish(); });
        tweens.clear();
        document.querySelectorAll('[data-route]').forEach(route => drawRoute(route, 1));
        document.querySelectorAll('[data-counter]').forEach(item => { item.textContent = new Intl.NumberFormat(data.lang === 'sv' ? 'sv-SE' : 'en-GB').format(Number(item.dataset.counter)); });
        document.querySelectorAll('[data-parallax], .hero-background, .service-card, .blog-card, .button').forEach(item => { item.style.removeProperty('transform'); item.style.removeProperty('will-change'); });
        document.querySelectorAll('.motion-ready').forEach(item => item.classList.add('is-revealed'));
    }
    // An existing reveal must never become hidden when motion is re-enabled.
    wake();
}

function prepareReveals() {
    const auto = minimal ? '.page-hero h1' : '.service-grid, .blog-grid, .chips, .footer-grid, .footer-info, .price-options, .two-column';
    document.querySelectorAll(auto).forEach(group => {
        if (minimal) group.dataset.reveal = 'fade-in';
        else group.dataset.stagger ??= '';
    });
    document.querySelectorAll('[data-stagger]').forEach(group => {
        [...group.children].forEach((child, index) => {
            child.dataset.reveal ||= group.classList.contains('chips') ? 'zoom-in' : 'fade-up';
            child.dataset.delay ??= String(Math.min(index, 6) * 80);
        });
    });
    if (!minimal) document.querySelectorAll('.breadcrumb, .prose>section, .contact-details, .map-placeholder, .form-layout aside, .blog-art, .editorial-art').forEach(item => { item.dataset.reveal ||= 'fade-up'; });
    const items = [...document.querySelectorAll('[data-reveal]')].filter(item => !item.closest('[data-motion="off"]') && (!minimal || item.matches('h1')));
    if (!('IntersectionObserver' in window)) { items.forEach(item => item.classList.add('is-revealed')); return; }
    const revealTargets = new Map();
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      for (const item of revealTargets.get(entry.target) || []) {
        if (entry.isIntersecting || !enabled) {
            item.classList.add('is-revealed');
            if (enabled) {
                item.style.willChange = 'transform, opacity';
                item.addEventListener('transitionend', () => item.style.removeProperty('will-change'), {once:true});
                // Also clear for zero-duration user overrides or interrupted transitions.
                setTimeout(() => item.style.removeProperty('will-change'), 1700);
            }
            if (item.dataset.once !== 'false') observer.unobserve(entry.target);
        } else if (item.dataset.once === 'false') item.classList.remove('is-revealed');
      }
    }), {threshold:0.08, rootMargin:'0px 0px -20px 0px'});
    items.forEach(item => {
        item.style.setProperty('--reveal-delay', `${clamp(Number(item.dataset.delay) || 0, 0, 1000)}ms`);
        item.classList.add('motion-ready');
        // A fully clipped element has no intersection area. Observe its stable wrapper.
        const target = item.dataset.reveal === 'clip-up' ? item.parentElement : item;
        revealTargets.set(target, [...(revealTargets.get(target) || []), item]);
        observer.observe(target);
    });
}

function prepareHeadings() {
    if (minimal) return;
    document.querySelectorAll('main section h2, .footer-info h2').forEach(heading => {
        if (heading.closest('[data-motion="off"]') || heading.querySelector('a, button')) return;
        const words = heading.textContent.trim().split(/\s+/);
        const fragment = document.createDocumentFragment();
        const fills = [];
        words.forEach((word, i) => {
            const span = document.createElement('span'); span.className = 'fill-word'; span.textContent = word;
            const fill = document.createElement('span'); fill.className = 'fill-ink'; fill.textContent = word; fill.setAttribute('aria-hidden','true');
            span.append(fill); fills.push(fill); fragment.append(span);
            if (i < words.length - 1) fragment.append(document.createTextNode(' '));
        });
        heading.replaceChildren(fragment);
        heading.classList.add('scroll-fill');
        effects.push(() => {
            if (!enabled) return;
            const rect = heading.getBoundingClientRect();
            if (rect.bottom < 0 || rect.top > innerHeight) return;
            const p = clamp((innerHeight * .92 - rect.top) / (innerHeight * .38));
            fills.forEach((fill, i) => fill.style.clipPath = `inset(0 ${(1-clamp(p*words.length-i))*100}% 0 0)`);
        });
    });
    document.querySelectorAll('[data-hero-title]').forEach(heading => {
        const lines = heading.innerHTML.split(/<br\s*\/?\s*>/i);
        if (heading.querySelector('a, button')) return;
        heading.replaceChildren();
        lines.forEach((line, i) => {
            const mask = document.createElement('span'); mask.className = 'hero-line-mask';
            const text = document.createElement('span'); text.className = 'hero-line';
            // Existing server-escaped title markup is decoded as text, never assigned as HTML.
            const decoder = document.createElement('textarea'); decoder.innerHTML = line; text.textContent = decoder.value;
            text.dataset.reveal = 'clip-up'; text.dataset.delay = String(i*120); mask.append(text); heading.append(mask);
            if (i<lines.length-1) heading.append(document.createTextNode(' '));
        });
    });
}

function prepareLoops() {
    const loops = document.querySelectorAll('[data-loop], [data-route="loop"], .header-quote');
    const observer = new IntersectionObserver(entries => entries.forEach(({target,isIntersecting}) => {
        target.classList.toggle('is-on-screen',isIntersecting);
        if (isIntersecting) visibleLoops.add(target); else visibleLoops.delete(target);
        if (!isIntersecting) target.style.removeProperty('will-change');
        wake();
    }), {threshold:0});
    loops.forEach(item => { observer.observe(item); item.addEventListener('pointerleave',wake); item.addEventListener('focusout',wake); });
    document.querySelectorAll('[data-route="scroll"]').forEach(route => {
        const section = route.closest('section');
        effects.push(() => {
            const rect = section.getBoundingClientRect();
            if (rect.bottom<0 || rect.top>innerHeight) return;
            const p = enabled ? clamp((innerHeight*.78-rect.top)/(rect.height*.75)) : 1;
            drawRoute(route,p);
            section.querySelectorAll('[data-process-step]').forEach((step,i)=>step.classList.toggle('step-reached',p >= i/5));
        });
    });
    document.querySelectorAll('[data-route="complete"]').forEach(route => tween(route,1000,p=>drawRoute(route,p)));
    const counterObserver = new IntersectionObserver(entries=>entries.forEach(entry=>{
        if(!entry.isIntersecting)return;
        const item=entry.target, value=Number(item.dataset.counter), formatter=new Intl.NumberFormat(data.lang==='sv'?'sv-SE':'en-GB');
        tween(item,1000,p=>item.textContent=formatter.format(Math.round(value*p)));
        counterObserver.unobserve(item);
    }),{threshold:.5});
    document.querySelectorAll('[data-counter]').forEach(item=>counterObserver.observe(item));
    document.querySelectorAll('[data-parallax]').forEach(item=>effects.push(()=>{
        if(item.closest('[data-motion=off]')||!enabled||!fine.matches)return;
        const rect=item.getBoundingClientRect();if(rect.bottom<0||rect.top>innerHeight)return;
        item.style.transform=`translateY(${clamp((rect.top-innerHeight/2)/innerHeight,-1,1)*Number(item.dataset.parallax)}px)`;
    }));
}

function prepareInteractions() {
    document.querySelectorAll('.service-card,.blog-card').forEach(card=>{
        card.addEventListener('pointermove',event=>{
            if(card.closest('[data-motion=off]')||!enabled||!fine.matches||event.pointerType==='touch'||card.matches(':focus-within'))return;
            const rect=card.getBoundingClientRect(), x=(event.clientX-rect.left)/rect.width-.5, y=(event.clientY-rect.top)/rect.height-.5;
            card.style.transform=`translateY(-8px) perspective(900px) rotateX(${-y*8}deg) rotateY(${x*8}deg)`;
            card.style.willChange='transform';
        });
        card.addEventListener('pointerleave',()=>{card.style.removeProperty('transform');card.style.removeProperty('will-change');});
    });
    document.querySelectorAll('.cta-band .button,.hero-copy .button').forEach(button=>{
        button.addEventListener('pointermove',event=>{
            if(button.closest('[data-motion=off]')||!enabled||!fine.matches||event.pointerType==='touch')return;
            const rect=button.getBoundingClientRect();button.style.transform=`translate(${clamp((event.clientX-rect.left-rect.width/2)*.08,-6,6)}px,${clamp((event.clientY-rect.top-rect.height/2)*.12,-4,4)}px)`;
        });
        button.addEventListener('pointerleave',()=>button.style.removeProperty('transform'));
    });
    document.querySelectorAll('.fjord-hero').forEach(hero=>{
        const image=hero.querySelector('.hero-background');
        hero.addEventListener('pointermove',event=>{
            if(hero.closest('[data-motion=off]')||!image||!enabled||!fine.matches||event.pointerType==='touch')return;
            const rect=hero.getBoundingClientRect();image.style.transform=`translate(${clamp((event.clientX-rect.left)/rect.width-.5,-.5,.5)*24}px,${clamp((event.clientY-rect.top)/rect.height-.5,-.5,.5)*24}px)`;
        });
        hero.addEventListener('pointerleave',()=>image?.style.removeProperty('transform'));
    });
    document.querySelectorAll('.accordion details').forEach(item=>item.addEventListener('toggle',()=>{
        const body=item.querySelector('p');if(item.open&&body&&enabled){body.animate([{opacity:0,transform:'translateY(-6px)'},{opacity:1,transform:'none'}],{duration:250,easing:'ease-out'});}
    }));
    document.querySelectorAll('[data-carousel], [data-testimonials]').forEach(list=>{
        if(list.children.length<2)return;
        const controls=document.createElement('div');controls.className='carousel-controls';
        for(const [direction,label] of [[-1,'previous'],[1,'next_slide']]){
            const button=document.createElement('button');button.type='button';button.className='button secondary';button.textContent=t(label);
            button.addEventListener('click',()=>list.scrollBy({left:direction*list.clientWidth*.8,behavior:enabled?'smooth':'instant'}));controls.append(button);
        }
        list.after(controls);list.tabIndex=0;
        list.addEventListener('keydown',event=>{if(!['ArrowLeft','ArrowRight'].includes(event.key))return;event.preventDefault();list.scrollBy({left:(event.key==='ArrowRight'?1:-1)*list.clientWidth*.8,behavior:enabled?'smooth':'instant'});});
        if(list.hasAttribute('data-testimonials')){
            const dots=document.createElement('div');dots.className='carousel-dots';
            [...list.children].forEach((slide,index)=>{const dot=document.createElement('button');dot.type='button';dot.setAttribute('aria-label',`${t('slide')} ${index+1}`);dot.addEventListener('click',()=>list.scrollTo({left:slide.offsetLeft-list.offsetLeft,behavior:enabled?'smooth':'instant'}));dots.append(dot);});controls.append(dots);
        }
    });
    const dialog=document.querySelector('#feature-video-dialog');
    document.querySelector('[data-video-open]')?.addEventListener('click',()=>{const video=dialog.querySelector('video');video.src=video.dataset.src;dialog.showModal();});
    dialog?.querySelector('[data-video-close]').addEventListener('click',()=>dialog.close());
    dialog?.addEventListener('close',()=>{const video=dialog.querySelector('video');video.pause();video.removeAttribute('src');video.load();});
    document.querySelectorAll('input[type=file]').forEach(input=>{
        const field=input.closest('.field');field.classList.add('upload-zone');
        if(input.name==='cv'){const hint=document.createElement('p');hint.className='small';hint.textContent=t('drop_hint');field.append(hint);}
        ['dragenter','dragover'].forEach(name=>field.addEventListener(name,()=>field.classList.add('drag-over')));
        ['dragleave','drop','change'].forEach(name=>field.addEventListener(name,()=>field.classList.remove('drag-over')));
        // Native file inputs handle dropping. No bypass of existing upload validation.
    });
}

function prepareContents() {
    if(!['legal','post'].includes(document.body.dataset.template))return;
    const article=document.querySelector('article.prose'), headings=[...article.querySelectorAll('section h2')];
    if(!headings.length)return;
    const nav=document.createElement('nav');nav.className='article-toc';nav.setAttribute('aria-label',t('contents'));
    const title=document.createElement('strong');title.textContent=t('contents');nav.append(title);
    const links=headings.map((heading,index)=>{heading.id ||= `section-${index+1}`;const link=document.createElement('a');link.href=`#${heading.id}`;link.textContent=heading.textContent;nav.append(link);return link;});
    article.prepend(nav);
    let bar=null;
    if(document.body.dataset.template==='post'){bar=document.createElement('div');bar.className='reading-progress';bar.setAttribute('role','progressbar');bar.setAttribute('aria-label',t('reading_progress'));bar.setAttribute('aria-valuemin','0');bar.setAttribute('aria-valuemax','100');const fill=document.createElement('span');bar.append(fill);document.body.append(bar);}
    effects.push(()=>{
        let active=0;headings.forEach((heading,index)=>{if(heading.getBoundingClientRect().top<innerHeight*.4)active=index;});
        links.forEach((link,index)=>{if(index===active)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');});
        if(bar){const rect=article.getBoundingClientRect(),p=clamp((innerHeight*.3-rect.top)/Math.max(1,rect.height-innerHeight*.5));bar.firstElementChild.style.transform=`scaleX(${p})`;bar.setAttribute('aria-valuenow',String(Math.round(p*100)));}
    });
}

function prepareForms() {
    const form=document.querySelector('.enquiry-form[data-kind=quote]');
    if(form){
        const progress=form.querySelector('progress');
        const track=document.createElement('div');track.className='motion-progress-track';track.setAttribute('aria-hidden','true');const fill=document.createElement('span');track.append(fill);progress.after(track);progress.classList.add('sr-only');
        const update=()=>{fill.style.transform=`scaleX(${progress.value/progress.max})`;const active=form.querySelector('[data-step]:not([hidden]),[data-summary]:not([hidden])');if(active&&enabled)active.animate([{opacity:0,transform:'translateX(12px)'},{opacity:1,transform:'none'}],{duration:300,easing:'ease-out'});};
        new MutationObserver(update).observe(progress,{attributes:true,attributeFilter:['value']});update();
    }
    const calculator=document.querySelector('#calculator');
    if(calculator){
        const area=calculator.querySelector('[name=area]');
        const label=document.createElement('label');label.className='estimate-range';label.textContent=t('area_slider');
        const range=document.createElement('input');range.type='range';range.min=area.min;range.max=area.max;range.value=area.value||60;range.setAttribute('aria-label',t('area_slider'));label.append(range);area.closest('.field').append(label);
        const track=document.createElement('span');track.className='range-fill';track.setAttribute('aria-hidden','true');label.append(track);
        const sync=()=>track.style.transform=`scaleX(${(Number(range.value)-Number(range.min))/(Number(range.max)-Number(range.min))})`;
        range.addEventListener('input',()=>{area.value=range.value;sync();});area.addEventListener('input',()=>{range.value=area.value;sync();});sync();
    }
    document.addEventListener('estimate-result',event=>{
        const {result,output}=event.detail;
        const accessible=document.createElement('span');accessible.className='sr-only';accessible.textContent=`${t('estimate_result')}: ${money(result.low)} – ${money(result.high)}`;
        if(data.rut)accessible.textContent+=` · ${t('after_rut')}: ${money(result.after_low)} – ${money(result.after_high)}`;
        const visual=document.createElement('span');visual.setAttribute('aria-hidden','true');output.replaceChildren(accessible,visual);
        tween(output,650,p=>{visual.textContent=`${money(result.low*p)} – ${money(result.high*p)}`;});
        if(data.rut){const note=document.createElement('p');note.textContent=`${t('after_rut')}: ${money(result.after_low)} – ${money(result.after_high)}`;output.append(note);const comparison=document.createElement('span');comparison.className='rut-comparison';comparison.setAttribute('aria-hidden','true');const after=document.createElement('span');comparison.append(after);output.append(comparison);tween(after,650,p=>after.style.transform=`scaleX(${clamp(result.after_high/result.high)*p})`);}
    });
}

export function initMotion() {
    try {
        syncPreference();
        document.querySelectorAll('[data-motion-toggle]').forEach(button=>button.addEventListener('click',()=>{paused=!paused;cookie('motion_pause',paused?'1':'0');syncPreference();}));
        reduced.addEventListener('change',syncPreference);
        document.addEventListener('visibilitychange',()=>{
            root.classList.toggle('motion-tab-hidden',document.hidden);lastTime=0;
            if(document.hidden){cancelAnimationFrame(frame);frame=0;}else wake();
        });
        if(!('IntersectionObserver' in window)){root.classList.remove('motion-on');root.classList.add('motion-off');enabled=false;return;}
        prepareContents();prepareHeadings();prepareReveals();
        if(!minimal){prepareLoops();prepareInteractions();prepareForms();}
        addEventListener('scroll',wake,{passive:true});addEventListener('resize',wake,{passive:true});
        document.fonts?.ready.then(wake);
        wake();
    } catch(error) {
        // Fail open: content and forms stay usable if an optional effect cannot initialise.
        root.classList.remove('motion-on');root.classList.add('motion-off');enabled=false;
        console.warn('Optional motion disabled:',error);
    }
}
