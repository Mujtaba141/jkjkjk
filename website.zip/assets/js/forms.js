import {t,data} from './i18n.js?v=11';
const storage={get(key){try{return sessionStorage.getItem(key);}catch{return null;}},set(key,value){try{sessionStorage.setItem(key,value);}catch{}},remove(key){try{sessionStorage.removeItem(key);}catch{}}};
export function initForms(){
 document.querySelectorAll('.enquiry-form').forEach(form=>{
  const steps=[...form.querySelectorAll('[data-step]')], summary=form.querySelector('[data-summary]'), submit=form.querySelector('[type=submit]'), errors=form.querySelector('.form-errors');let current=0;
  const show=()=>{if(!steps.length)return;steps.forEach((step,i)=>step.hidden=i!==current);summary.hidden=current!==steps.length;form.querySelector('[data-back]').hidden=current===0;form.querySelector('[data-next]').hidden=current===steps.length;submit.hidden=current!==steps.length;form.querySelector('progress').value=current+1;form.querySelector('#step-status').textContent=`${t('step')} ${current+1} / ${steps.length+1}`;};
  const validate=element=>{let first=null;element.querySelectorAll('input,select,textarea').forEach(input=>{input.removeAttribute('aria-invalid');input.setCustomValidity('');if(!input.checkValidity()){input.setCustomValidity(input.validity.valueMissing?t('required'):t('invalid'));}if(!input.checkValidity()){input.setAttribute('aria-invalid','true');first??=input;}});if(first){first.reportValidity();first.focus();return false;}return true;};
  const makeSummary=()=>{const list=form.querySelector('#quote-summary');list.replaceChildren();for(const [key,value] of new FormData(form)){if(['csrf','ticket','website','language'].includes(key)||value===''||value instanceof File)continue;const dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=t(key);dd.textContent=key==='date'?new Intl.DateTimeFormat(data.lang==='sv'?'sv-SE':'en-GB').format(new Date(value+'T12:00:00')):value==='1'?t('yes'):['service','customer_type','elevator','price_model'].includes(key)?t(value):value;list.append(dt,dd);}const files=[...form.querySelectorAll('input[type=file]')].flatMap(input=>[...input.files]);if(files.length){const dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=t('summary_files');dd.textContent=files.map(f=>f.name).join(', ');list.append(dt,dd);}};
  if(steps.length){
   const draftKey='vercel-demo-unused-draft', draftControl=form.querySelector('#save-draft');let saved=null;try{saved=JSON.parse(storage.get(draftKey)||'null');}catch{}
   if(saved&&Date.now()-saved.at<2*60*60*1000){draftControl.checked=true;for(const [key,value] of Object.entries(saved.fields)){const input=form.elements.namedItem(key);if(!input||input.type==='file'||input.type==='hidden'||key==='consent')continue;if(input.type==='checkbox')input.checked=value===true;else input.value=value;}}
   const persist=()=>{if(!draftControl.checked){storage.remove(draftKey);return;}const fields={};form.querySelectorAll('input:not([type=hidden]):not([type=file]),select,textarea').forEach(input=>{if(input.name&&!['consent','website'].includes(input.name))fields[input.name]=input.type==='checkbox'?input.checked:input.value;});storage.set(draftKey,JSON.stringify({at:Date.now(),fields}));};
   form.addEventListener('input',persist);draftControl.addEventListener('change',persist);form.querySelector('#clear-draft').addEventListener('click',()=>{storage.remove(draftKey);draftControl.checked=false;});
   form.querySelector('[data-next]').addEventListener('click',()=>{if(validate(steps[current])){current++;if(current===steps.length)makeSummary();show();(current===steps.length?summary:steps[current]).setAttribute('tabindex','-1');(current===steps.length?summary:steps[current]).focus();}});
   form.querySelector('[data-back]').addEventListener('click',()=>{current--;show();steps[current].setAttribute('tabindex','-1');steps[current].focus();});show();
  }
  form.noValidate=true;form.addEventListener('input',event=>{if(typeof event.target.setCustomValidity==='function')event.target.setCustomValidity('');});
  form.addEventListener('submit',async event=>{
   event.preventDefault();errors.replaceChildren();
   for(let i=0;i<steps.length;i++){if([...steps[i].querySelectorAll('input,select,textarea')].some(input=>!input.checkValidity())){current=i;show();validate(steps[i]);return;}}
   if(steps.length&&current!==steps.length){current=steps.length;makeSummary();show();summary.setAttribute('tabindex','-1');summary.focus();return;}
   if(!validate(form))return;
   const fileInputs=[...form.querySelectorAll('input[type=file]')];for(const input of fileInputs){const files=[...input.files];const types=input.name==='cv'?['application/pdf']:['image/jpeg','image/png','image/webp'];if(files.length>(input.name==='cv'?1:5)||files.some(file=>file.size>(input.name==='cv'?5:3)*1024*1024||!types.includes(file.type))){errors.textContent=t('upload_error');errors.focus();return;}}
   errors.textContent=data.lang==='sv'?'Demo klar — inget har skickats eller sparats.':'Demo complete — nothing was sent or saved.';errors.setAttribute('role','status');errors.focus();

  });
 });
}
