export function initNav(){
 const header=document.querySelector('.site-header'); const nav=document.querySelector('.navigation');
 const desktop=matchMedia('(min-width:1181px)');const sync=()=>{if(nav)nav.open=desktop.matches;};sync();desktop.addEventListener('change',sync);
 let previousY=scrollY;
 addEventListener('scroll',()=>{const y=scrollY;header?.classList.toggle('compact',y>40);if(Math.abs(y-previousY)>6){header?.classList.toggle('header-away',y>220&&y>previousY&&!header.matches(':focus-within')&&!nav?.matches('[open]:hover'));previousY=y;}},{passive:true});
 header?.addEventListener('focusin',()=>header.classList.remove('header-away'));
 document.querySelectorAll('.nav-group').forEach(group=>group.addEventListener('toggle',()=>{if(group.open)document.querySelectorAll('.nav-group').forEach(other=>{if(other!==group)other.open=false;});}));
 document.addEventListener('keydown',event=>{if(event.key==='Escape'){document.querySelectorAll('.navigation details[open]').forEach(d=>d.open=false);if(nav?.open){nav.open=false;nav.querySelector('summary').focus();}}});
 document.addEventListener('click',event=>{if(!event.target.closest('.navigation'))document.querySelectorAll('.nav-group[open]').forEach(d=>d.open=false);});
}
