document.querySelectorAll('[data-demo-submit]').forEach(b=>b.type='submit');
