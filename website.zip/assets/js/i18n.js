export const data = JSON.parse(document.getElementById('site-data')?.textContent || '{}');
export const t = key => data.strings?.[`ui.${key}`] ?? key;
export const money = value => new Intl.NumberFormat(data.lang === 'sv' ? 'sv-SE' : 'en-GB', {style:'currency',currency:'SEK',maximumFractionDigits:0}).format(value);
export const cookie = (key,value,days=365) => { document.cookie = `${key}=${encodeURIComponent(value)}; Max-Age=${days*86400}; Path=/; SameSite=Lax${location.protocol==='https:'?'; Secure':''}`; };
export const readCookie = key => {const item=document.cookie.split('; ').find(v=>v.startsWith(`${key}=`));try{return item?decodeURIComponent(item.slice(key.length+1)):null;}catch{return null;}};
export function initLanguage(){}
